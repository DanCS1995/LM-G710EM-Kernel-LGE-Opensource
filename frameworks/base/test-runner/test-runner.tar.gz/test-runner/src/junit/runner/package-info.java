/**
 * Utility classes supporting the junit test framework.
 */
package junit.runner;